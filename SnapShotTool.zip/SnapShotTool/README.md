# SnapShotTool
A java swing based application used to take screenshots and export them to a file.
